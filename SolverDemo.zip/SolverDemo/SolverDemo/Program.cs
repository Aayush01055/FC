﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolverDemo.Model;

namespace SolverDemo
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var order = GenerateOrder();
            var tanks = GenerateTanks();

            var loadoutQuantity = GetLoadoutQuantity();

            order.LoadoutQuantity = loadoutQuantity;
            var costMinimizer = new MinimizeCostSolver();
            costMinimizer.Initialize(tanks, order);

            var maximizeLoadoutQuantitySolver = new MaximizeLoadoutQuantitySolver();
            maximizeLoadoutQuantitySolver.Initialize(tanks, order);

            Console.WriteLine("Start solving model");
            if (costMinimizer.Solve())
            {
                Console.WriteLine("Model solved with initial loadout quantity");
                DisplayResult(tanks, order);
            }
            else
            {
                Console.WriteLine("Model cannot be solved with initial loadout quantity");
                Console.WriteLine("Solving maximum quantity system can loadout");
                if (maximizeLoadoutQuantitySolver.Solve())
                {
                    var quantity = (int)tanks.Sum(tank => tank.LoadoutQuantity);
                    if (quantity > 0)
                    {
                        Console.WriteLine("Possible to loadout {0}L", quantity);
                        Console.WriteLine("Optimizing blending for {0}L", quantity);
                        order.LoadoutQuantity = quantity;
                        costMinimizer.Initialize(tanks, order);
                        if (costMinimizer.Solve())
                        {
                            DisplayResult(tanks, order);
                        }
                    }
                    else
                    {
                        DisplayError();
                    }
                }
                else
                {
                    DisplayError();
                }
            }
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }

        private static int GetLoadoutQuantity()
        {
            var loadoutQuantity = 0;
            while (loadoutQuantity == 0)
            {
                Console.Write("Enter loadout quantity (int:100-40000):");
                var quantityInStr = Console.ReadLine();
                var enteredQuantity = 0;
                if (int.TryParse(quantityInStr, out enteredQuantity))
                {
                    loadoutQuantity = enteredQuantity;
                }
                else
                {
                    Console.Clear();
                }
            }
            return loadoutQuantity;
        }


        private static Order GenerateOrder()
        {
            var order = new Order
            {
                LoadoutQuantity = 3000,
                OrderId = "0001",
                QualityAttributes = new BoundedQualityAttributeCollection
                {
                    new BoundedQualityAttribute
                    {
                        Name = "Density",
                        Minimum = 1.03,
                        Maximum = 1.034
                    },
                    new BoundedQualityAttribute
                    {
                        Name = "Fat",
                        Minimum = 3.9,
                        Maximum = 4.1
                    },
                    new BoundedQualityAttribute
                    {
                        Name = "SNF",
                        Minimum = 7,
                        Maximum = 10
                    }
                }
            };
            return order;
        }

        private static List<Tank> GenerateTanks()
        {
            var tanks = new List<Tank>
            {
                new Tank
                {
                    Name = "TK-001_High",
                    ProductCost = 1.2,
                    QuantityInTank = 200,
                    QualityAttributes = new QualityAttributeCollection
                    {
                        new QualityAttribute
                        {
                            Name = "Density",
                            Value = 1.033
                        },
                        new QualityAttribute
                        {
                            Name = "Fat",
                            Value = 4
                        },
                        new QualityAttribute
                        {
                            Name = "SNF",
                            Value = 9
                        }
                    }
                },
                new Tank
                {
                    Name = "TK-002_Regular",
                    ProductCost = 1,
                    QuantityInTank = 1500,
                    QualityAttributes = new QualityAttributeCollection
                    {
                        new QualityAttribute
                        {
                            Name = "Density",
                            Value = 1.0315
                        },
                        new QualityAttribute
                        {
                            Name = "Fat",
                            Value = 3.8
                        },
                        new QualityAttribute
                        {
                            Name = "SNF",
                            Value = 8.6
                        }
                    }
                },
                new Tank
                {
                    Name = "TK-003_Low",
                    ProductCost = 0.8,
                    QuantityInTank = 700,
                    QualityAttributes = new QualityAttributeCollection
                    {
                        new QualityAttribute
                        {
                            Name = "Density",
                            Value = 1.0298
                        },
                        new QualityAttribute
                        {
                            Name = "Fat",
                            Value = 3.3
                        },
                        new QualityAttribute
                        {
                            Name = "SNF",
                            Value = 8.2
                        }
                    }
                },
                new Tank
                {
                    Name = "Cream",
                    ProductCost = 4.5,
                    QuantityInTank = 20,
                    QualityAttributes = new QualityAttributeCollection
                    {
                        new QualityAttribute
                        {
                            Name = "Density",
                            Value = 1.005
                        },
                        new QualityAttribute
                        {
                            Name = "Fat",
                            Value = 36.6
                        },
                        new QualityAttribute
                        {
                            Name = "SNF",
                            Value = 5.55
                        }
                    }
                },
                new Tank
                {
                    Name = "Skim",
                    ProductCost = 2,
                    QuantityInTank = 1500,
                    QualityAttributes = new QualityAttributeCollection
                    {
                        new QualityAttribute
                        {
                            Name = "Density",
                            Value = 1.036
                        },
                        new QualityAttribute
                        {
                            Name = "Fat",
                            Value = 0.02
                        },
                        new QualityAttribute
                        {
                            Name = "SNF",
                            Value = 10.15
                        }
                    }
                }
            };
            return tanks;
        }

        private static void DisplayResult(List<Tank> tanks, Order order)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            foreach (var tank in tanks)
            {
                Console.WriteLine("{0, -20} \t: {1:0}L", tank.Name, tank.LoadoutQuantity);
            }
        }

        private static void DisplayError(string errorMessage = "Model cannot be solved with given input")
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(errorMessage);
        }
      
    }
}