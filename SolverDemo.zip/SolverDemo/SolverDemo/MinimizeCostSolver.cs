﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.SolverFoundation.Services;
using SolverDemo.Model;

namespace SolverDemo
{
    public class MinimizeCostSolver : SolverBase
    {
        protected override void PopulateModel(Microsoft.SolverFoundation.Services.Model model, List<Tank> tanks, Order order)
        {
            var sTankNames = new Set(Domain.Any, "sTankNames");
            var sQualityAttributes = new Set(Domain.Any, "sQualityAttributes");

            var pQuantities = new Parameter(Domain.IntegerNonnegative,
                "pQuantities",
                sTankNames);
            var pProductCosts = new Parameter(Domain.RealNonnegative, "pProductCosts", sTankNames);
            var pTankQualityAttributes = new Parameter(Domain.RealNonnegative, "pTankQualityAttributes",
                sTankNames, sQualityAttributes);
            var pOrderMaximumQualityAttributes = new Parameter(Domain.RealNonnegative, "pOrderMaximumQualityAttributes",
                sQualityAttributes);
            var pOrderMinimumQualityAttributes = new Parameter(Domain.RealNonnegative, "pOrderMinimumQualityAttributes",
                sQualityAttributes);
            var pLoadoutQuantity = new Parameter(Domain.IntegerNonnegative, "pLoadoutQuantity");

            pQuantities.SetBinding(tanks,
                tank => tank.QuantityInTank,
                tank => tank.Name);
            pProductCosts.SetBinding(tanks,
                tank => tank.ProductCost,
                tank => tank.Name);
            pTankQualityAttributes.SetBinding(tanks.SelectMany(tank => tank.QualityAttributes.Select(attribute => new
            {
                TankName = tank.Name,
                AttributeName = attribute.Name,
                attribute.Value
            })),
                attribute => attribute.Value,
                attribute => attribute.TankName,
                attribute => attribute.AttributeName);
            pOrderMaximumQualityAttributes.SetBinding(order.QualityAttributes,
                attribute => attribute.Maximum,
                attribute => attribute.Name);
            pOrderMinimumQualityAttributes.SetBinding(order.QualityAttributes,
                attribute => attribute.Minimum,
                attribute => attribute.Name);
            pLoadoutQuantity.SetBinding(order.LoadoutQuantity);

            model.AddParameter(pQuantities);
            model.AddParameter(pProductCosts);
            model.AddParameter(pTankQualityAttributes);
            model.AddParameter(pOrderMaximumQualityAttributes);
            model.AddParameter(pOrderMinimumQualityAttributes);
            model.AddParameter(pLoadoutQuantity);

            var dQuantityToLoadout = new Decision(Domain.RealNonnegative, "dQuantityToLoadout", sTankNames);
            dQuantityToLoadout.SetBinding(tanks, "LoadoutQuantity", "Name");
            model.AddDecision(dQuantityToLoadout);

            model.AddConstraint("cLoadoutQuantity",
                Microsoft.SolverFoundation.Services.Model.Equal(
                    Microsoft.SolverFoundation.Services.Model.Sum(
                        Microsoft.SolverFoundation.Services.Model.ForEach(sTankNames,
                            tankName => dQuantityToLoadout[tankName]
                            )
                        ),
                    pLoadoutQuantity
                    )
                );

            model.AddConstraint("cTankQuantity",
                Microsoft.SolverFoundation.Services.Model.ForEach(sTankNames,
                    tankName =>
                        Microsoft.SolverFoundation.Services.Model.LessEqual(
                            dQuantityToLoadout[tankName],
                            pQuantities[tankName]
                            )
                    )
                );

            model.AddConstraint("cOrderQuality",
                Microsoft.SolverFoundation.Services.Model.ForEach(sQualityAttributes,
                    qualityAttribute =>
                        Microsoft.SolverFoundation.Services.Model.LessEqual(
                            pOrderMinimumQualityAttributes[qualityAttribute],
                            Microsoft.SolverFoundation.Services.Model.Quotient(
                                Microsoft.SolverFoundation.Services.Model.Sum(
                                    Microsoft.SolverFoundation.Services.Model.ForEach(sTankNames,
                                        tankName =>
                                            Microsoft.SolverFoundation.Services.Model.Product(dQuantityToLoadout[tankName],
                                                pTankQualityAttributes[tankName, qualityAttribute])
                                        )
                                    ),
                                pLoadoutQuantity
                                ),
                            pOrderMaximumQualityAttributes[qualityAttribute]
                            )
                    )
                );

            model.AddGoal("gMinimizeTotalCost", GoalKind.Minimize,
                Microsoft.SolverFoundation.Services.Model.Sum(
                    Microsoft.SolverFoundation.Services.Model.ForEach(sTankNames,
                        tankName => Microsoft.SolverFoundation.Services.Model.Sum(
                            Microsoft.SolverFoundation.Services.Model.Product(
                                dQuantityToLoadout[tankName],
                                pProductCosts[tankName]
                                ),
                            20
                            )
                        )
                    )
                );
        }
    }
}