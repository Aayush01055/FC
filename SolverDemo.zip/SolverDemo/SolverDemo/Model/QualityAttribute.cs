﻿namespace SolverDemo.Model
{
    public class QualityAttribute
    {
        public string Name { get; set; }
        public double Value { get; set; }
    }
}
