﻿using System.Collections.ObjectModel;

namespace SolverDemo.Model
{
    public class QualityAttributeCollection: KeyedCollection<string, QualityAttribute>
    {
        protected override string GetKeyForItem(QualityAttribute item)
        {
            return item.Name;
        }
    }
}
