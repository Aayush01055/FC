﻿namespace SolverDemo.Model
{
    public class BoundedQualityAttribute
    {
        public string Name { get; set; }
        public double Minimum { get; set; }
        public double Maximum { get; set; }
    }
}
