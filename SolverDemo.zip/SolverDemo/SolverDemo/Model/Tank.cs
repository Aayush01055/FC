﻿namespace SolverDemo.Model
{
    public class Tank
    {
        public string Name { get; set; }
        public int QuantityInTank { get; set; }
        public double LoadoutQuantity { get; set; }
        public double ProductCost { get; set; }
        public QualityAttributeCollection QualityAttributes { get; set; }
    }
}
