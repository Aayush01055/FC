﻿namespace SolverDemo.Model
{
    public class Order
    {
        public string OrderId { get; set; }
        public double LoadoutQuantity { get; set; }
        public BoundedQualityAttributeCollection QualityAttributes { get; set; }
    }
}
