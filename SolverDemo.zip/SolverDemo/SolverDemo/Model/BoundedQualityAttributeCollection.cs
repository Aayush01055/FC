﻿using System.Collections.ObjectModel;

namespace SolverDemo.Model
{
    public class BoundedQualityAttributeCollection:KeyedCollection<string, BoundedQualityAttribute>
    {
        protected override string GetKeyForItem(BoundedQualityAttribute item)
        {
            return item.Name;
        }
    }
}
