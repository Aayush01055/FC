﻿using System.Collections.Generic;
using Microsoft.SolverFoundation.Services;
using SolverDemo.Model;

namespace SolverDemo
{
    public abstract class SolverBase
    {
        
        private SolverContext _context;

        public void Initialize(List<Tank> tanks, Order order)
        {
            _context = new SolverContext();
            var model = _context.CreateModel();
            PopulateModel(model, tanks, order);
        }

        protected abstract void PopulateModel(Microsoft.SolverFoundation.Services.Model model, List<Tank> tanks, Order order);

        public bool Solve()
        {
            var report = _context.Solve();
            var solutionFound = report.Quality == SolverQuality.LocalOptimal || report.Quality == SolverQuality.Optimal;
            if (solutionFound)
            {
                _context.PropagateDecisions();
            }
            return solutionFound;
        }
    }
}
